from yatpkg.util.mos import list_harddrives

if __name__ == '__main__':
    df = list_harddrives()
    print(df)
    pass
